# stokity_fractal_bot.py
# Bot Autotrade Stokity: 2 Candle + Fractal 5 + Support/Resistance + Martingale 1-3
# Placeholder code - isi dengan logika bot yang sudah dibuat

def run_bot():
    print("Bot berjalan dengan strategi 2 candle + fractal 5 + SR + martingale 1-3")

if __name__ == "__main__":
    run_bot()
